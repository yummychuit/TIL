from django.apps import AppConfig


class Workshop19Config(AppConfig):
    name = 'workshop19'
